import styles from "@/styles/Footer/index.module.scss";
import Link from "next/link";

const Footer = () => {
  return (
    <div className={styles.footer} id="footer">
      <div className={styles.footerWrapper}>
        <div className={styles.footerColumn}>
          <img src="/images/logo.png" />
        </div>
        <div className={styles.footerColumn}>
          <p className={styles.footerColumnHeading}>Thông tin liên hệ</p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/Call.svg" />
              <span>0387 514 462</span>
            </Link>
          </p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/Mail.svg" />
              <span>Telegram: @trafficuser</span>
            </Link>
          </p>
        </div>
        <div className={styles.footerColumn}>
          <p className={styles.footerColumnHeading}>Thông tin</p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/verify.svg" />
              <span>Giới thiệu</span>
            </Link>
          </p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/lock.svg" />
              <span>Chính sách bảo mật</span>
            </Link>
          </p>
        </div>
        <div className={styles.footerColumn}>
          <p className={styles.footerColumnHeading}>Thông tin dịch vụ</p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/send.svg" />
              <span>Dịch vụ Entity</span>
            </Link>
          </p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/send.svg" />
              <span>Dịch vụ backlink tool</span>
            </Link>
          </p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/send.svg" />
              <span>Dịch vụ backlink gov</span>
            </Link>
          </p>
          <p className={styles.footerColumnContent}>
            <Link href={"#"}>
              <img src="/images/send.svg" />
              <span>Dịch vụ backlink báo</span>
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
