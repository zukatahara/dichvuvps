import styles from "@/styles/Information/information.module.css";
import { useEffect, useState } from "react";

const Information = (props: any) => {
  return (
    <>
      <div className={styles.information} id="infor">
        <div className={styles.first_block}>
          <span className={styles.first_title}>
            Hệ thống <span className={styles.text_gradient}> BACKLINK</span> của
            chúng tôi.
          </span>

          <br />
          <span className={styles.first_description}>
            <strong>Hệ thống Backlink PBN</strong> (Private Blog Network) mà
            dichvupbn.com tâm huyết xây dựng đến nay. Chúng tôi tích lũy nhiều
            năm trời kinh nghiệm để tìm ra những phương pháp, kỹ thuật và nguyên
            lý SEO tốt nhất cho khách hàng.
          </span>
          <br />
          <button
            className={styles.btn_contact}
            onClick={() => document?.getElementById("prices")?.scrollIntoView()}
          >
            <img src="/images/tag.svg" width={20} height={20} />
            <p>Bảng giá</p>
          </button>
        </div>

        <div className={styles.image_block}>
          <img width={300} height={300} src="/images/bg-1.png" />
        </div>
      </div>
      <div className={styles.benefit}>
        <div className={styles.first_block}>
          <span className={styles.second_title}>
            Lợi ích
            <p className={styles.text_gradient_1}> KHI SỬ DỤNG TRAFFIC USER</p>
          </span>
          <br />
          <span className={styles.second_description}>
            Chúng tôi cam đoan những thông tin xoay quanh về các sản phẩm dịch
            vụ được trình bày và giới thiệu cho khách hàng trên website{" "}
            <span style={{ color: "#5708CD", fontWeight: "600" }}>
              {" "}
              dichvupbn.com
            </span>{" "}
            là đúng với sự thật. Đồng thời chúng tôi cam kết thực hiện đúng và
            đầy đủ những gì chúng tôi đã nêu trong các hạng mục dịch vụ triển
            khai với khách hàng.
          </span>
          <br />
        </div>

        <div className={styles.image_block}>
          <img width={300} height={300} src="/images/bg-2.png" />
        </div>
      </div>
      <div className={styles.value_block}>
        <div className={styles.thirth_block}>
          <span className={styles.thirth_title}> Những giá trị </span>
          <p className={styles.text_gradient_1}> MÀ CHÚNG TÔI ĐEM LẠI</p>
        </div>
        <div className={styles.images_values_block}>
          <div className={styles.images_block}>
            <img src="/images/antoantuyetdoi.png" width={240} height={190} />
            <strong className={styles.title}>An toàn tuyệt đối</strong>
            <br />
            <p className={styles.description}>
              Đảm bảo các backlinks của bạn được tạo bằng tay hoàn toàn tự
              nhiên, thân thiện với Google nên bạn cứ yên tâm.
            </p>
          </div>
          <div className={styles.images_block}>
            <img src="/images/tietkiemchiphi.png" width={240} height={190} />
            <strong className={styles.title}>Tiết kiệm chi phí</strong>
            <br />
            <p className={styles.description}>
              Chúng tôi cung cấp dịch vụ PBN giá rẻ không có nghĩa, các PBN này
              không chất lượng. Cam kết tất cả các PBN đều điểm số chất lượng
              trên 20.
            </p>
          </div>
          <div className={styles.images_block}>
            <img src="/images/hieuqua-benvung.png" width={240} height={190} />
            <strong className={styles.title}>Hiệu quả - Bền vững</strong>
            <br />
            <p className={styles.description}>
              Dịch vụ cung cấp các backlinks DOFOLLOW chất lượng tăng cường sức
              mạnh xếp hạng của bạn.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};
export default Information;
