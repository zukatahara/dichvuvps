const arr = [
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
  {
    descone:
      "Đầu tư một hệ thống PBN khá tốn kém và mất nhiều thời gian. Những chi phí mà bạn phải bỏ ra để xây dựng có thể kể đến như tên miền, hosting, content, nhân sự quản lý.",
    desctwo:
      "Lấy một ví dụ đơn giản, nếu xây 1 website bạn sẽ cần mua tên miền với giá 200-750.000; hosting 1 năm khoảng 500.000-2.000.000, content 30 bài khoản 6-10 triệu, chi phí thuê nhân sự… Vậy, để đầu tư một website bạn sẽ mất đâu đó từ 8-15 triệu.",
    descthree:
      "Chưa kể, thời gian thực hiện cũng sẽ sẽ mất khá lâu, dao động từ 3-6 tháng tùy chủ đề. Một vài chủ đề khó thời gian sẽ lâu hơn rất nhiều.",
    descfour:
      "Như vậy, để xây dựng một PBN bài bản, có thể áp dụng được sẽ mất rất nhiều thời gian và chi phí. Và thay vìphải bỏ một số tiền lớn để tự xây dựng hệ thống PBN, việc thuê dịch vụ PBN sẽ là giải pháp hợp lý, tối ưu mà bạn có thể lựa chọn.",
    descimg: "image-1.png",
  },
];
export default arr;
